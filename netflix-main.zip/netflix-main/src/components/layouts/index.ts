export { default as MainHeader } from "./MainHeader";
export { default as Footer } from "./Footer";
